rm -rf ./*.txt
rm -rf ./*.json
rm -rf ./output/*.bmp
rm -rf ./output/*.jpg