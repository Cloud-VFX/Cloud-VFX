package pt.ulisboa.tecnico.cnv.webserver;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.lang.management.ManagementFactory;

import com.amazonaws.services.cloudwatch.AmazonCloudWatch;
import com.amazonaws.services.cloudwatch.AmazonCloudWatchClientBuilder;
import com.amazonaws.services.cloudwatch.model.Dimension;
import com.amazonaws.services.cloudwatch.model.MetricDatum;
import com.amazonaws.services.cloudwatch.model.PutMetricDataRequest;
import com.amazonaws.services.cloudwatch.model.StandardUnit;
import com.amazonaws.AmazonClientException;
import com.sun.management.OperatingSystemMXBean;

public class CpuUsagePublisher {
    private static final AmazonCloudWatch cloudWatch = AmazonCloudWatchClientBuilder.standard().build();
    private static String instanceId = null;

    public CpuUsagePublisher() {
        instanceId = getInstanceId();
        if (instanceId == null) {
            System.err.println("Instance ID could not be retrieved. CPU usage will not be published.");
        }
    }

    public void publishCpuUsage() {
        OperatingSystemMXBean osBean = ManagementFactory.getPlatformMXBean(OperatingSystemMXBean.class);
        double cpuLoad = osBean.getSystemCpuLoad() * 100;

        if (cpuLoad < 0) {
            System.out.println("CPU load information not available.");
            return;
        }

        MetricDatum datum = new MetricDatum()
                .withMetricName("CPUUtilization")
                .withUnit(StandardUnit.Percent)
                .withValue(cpuLoad)
                .withStorageResolution(1); // Setting high-resolution metrics

        if (instanceId != null) {
            datum.withDimensions(new Dimension().withName("InstanceId").withValue(instanceId));
        }

        PutMetricDataRequest request = new PutMetricDataRequest()
                .withNamespace("Custom/Metrics")
                .withMetricData(datum);

        try {
            cloudWatch.putMetricData(request);
            System.out.println("Successfully published CPU usage to CloudWatch: " + cpuLoad + "%");
        } catch (AmazonClientException ace) {
            System.err.println("Error publishing CPU usage to CloudWatch: " + ace.getMessage());
        }
    }

    public static String getInstanceId() {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://169.254.169.254/latest/meta-data/instance-id"))
                .GET()
                .build();
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                return response.body();
            } else {
                System.err.println("Failed to get instance ID. HTTP response code: " + response.statusCode());
                return null;
            }
        } catch (Exception e) {
            System.err.println("Error retrieving instance ID: " + e.getMessage());
            return null;
        }
    }

    public static void main(String[] args) {
        CpuUsagePublisher publisher = new CpuUsagePublisher();
        // Publish CPU usage periodically, for example every minute
        while (true) {
            publisher.publishCpuUsage();
            try {
                Thread.sleep(60000); // Sleep for 1 minute
            } catch (InterruptedException e) {
                System.err.println("Sleep interrupted: " + e.getMessage());
            }
        }
    }
}
